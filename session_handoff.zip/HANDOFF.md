# Companion Project — Session Handoff

## What this is

Two separate deliverables in progress:

1. `legacy.zip` — Amalgam archived. Working, tested, frozen. Not touched again.
2. `ai_company_final.zip` — the n8n AI Company planning harness (23 agents). Fixes applied this session: system-prompt placeholders replaced with real file reads, connection graph fixed so Load System Prompts runs after Agent Registry.
3. **hermes_avatar_tools/** — Hermes plugin. ALL CODE LOST IN SANDBOX RESET. Reconstruct from spec below.
4. **hermes-avatar-companion/backend/** — Companion backend. ALL CODE LOST IN SANDBOX RESET. Reconstruct from spec below.

---

## Architecture (locked, do not relitigate)

```
User mic
  → wake word (openWakeWord) or PTT key
  → VAD (webrtcvad) frames
  → STT (faster-whisper) → transcribed text
  → HermesClient POST /v1/responses (streaming SSE)
      headers: Authorization: Bearer $API_SERVER_KEY
               X-Hermes-Session-Key: "companion"
      body:    {input, instructions (character.to_instructions()), conversation, stream:true}
  → parse SSE events:
      response.output_text.delta      → TextDelta(text)
      response.output_item.added      → (tool call started, name only)
      response.function_call_arguments.done → ToolCall(call_id, name, arguments)
      response.completed              → ResponseComplete(response_id)
  → CompanionOrchestrator.broadcast(wire_message)
      text_delta    → SpeechOutput.feed_text() → sentence buffer → TTS → audio bytes → shell
      tool_call     → broadcast to shell (shell acts on it locally)
      turn_complete → SpeechOutput.flush() → broadcast to shell
      error         → broadcast to shell
  → WebSocket server (ws://127.0.0.1:8765) → Electron shell
```

Electron shell (NOT STARTED):
- Full-screen transparent overlay window (BrowserWindow, frame:false, transparent:true, skipTaskbar:true, alwaysOnTop:true)
- Click-through when idle: setIgnoreMouseEvents(true, {forward:true}), off when cursor hits avatar bounds
- Four mouse behaviors ON AVATAR: drag=move, scroll=resize, right-click=hide
- VRM rendering + lipsync + emotion + animation (fresh rewrite from scratch — do NOT port from legacy.zip)
- Receives JSON messages over local WebSocket, acts on them

---

## Plugin: hermes_avatar_tools/

### File structure
```
hermes_avatar_tools/
  __init__.py       ← register(ctx) entrypoint
  plugin.yaml       ← manifest
  schemas.py        ← tool schemas (ALL_SCHEMAS list)
  tools.py          ← handlers (validate + return string, never raise, never do local I/O)
  README.md
  skills/
    avatar-behavior/
      SKILL.md      ← behavioral policy
  tests/
    test_registration.py
```

### plugin.yaml
```yaml
name: avatar-companion-tools
version: "1.0"
provides_tools: [set_emotion, play_animation, show_overlay, hide_overlay, move_avatar, resize_avatar]
provides_hooks: []
requires_env: []
```

### schemas.py — exact enums
```python
EMOTIONS = ["neutral","happy","sad","angry","surprised","thinking","shy","excited","confident","tired","scared","bored","loving"]
ANIMATIONS = ["wave","nod","shake_head","shrug","point","think","celebrate","stretch","sleep","wake"]
DIRECTIONS = ["left","right","top_left","top_right","bottom_left","bottom_right","center"]
SIZES = ["small","medium","large","slightly_smaller","slightly_bigger"]
TOOLSET = "avatar"
```

### tools.py — handler pattern
Every handler: validate input against enum, return ok string or `"[tool_name] error: detail"`. Never raise. Never do I/O. The real effect happens in the Electron shell watching the SSE stream for these tool names.

### SKILL.md — key rules
- At most one animation per reply, at most one emotion per reply
- Only call show/hide overlay when user explicitly asks
- Never move/resize proactively — user has direct mouse control
- When in doubt, do nothing — most turns should have zero tool calls

### __init__.py
```python
from .schemas import ALL_SCHEMAS
from .tools import handle_set_emotion, handle_play_animation, handle_show_overlay, handle_hide_overlay, handle_move_avatar, handle_resize_avatar

TOOLSET = "avatar"
_HANDLERS = {"set_emotion": handle_set_emotion, "play_animation": handle_play_animation,
             "show_overlay": handle_show_overlay, "hide_overlay": handle_hide_overlay,
             "move_avatar": handle_move_avatar, "resize_avatar": handle_resize_avatar}

def register(ctx):
    from pathlib import Path
    for schema in ALL_SCHEMAS:
        ctx.register_tool(name=schema["name"], toolset=TOOLSET, schema=schema, handler=_HANDLERS[schema["name"]])
    ctx.register_skill(name="avatar-behavior", path=str(Path(__file__).parent / "skills" / "avatar-behavior"))
```

### Install note (confirmed from source)
- `platform_toolsets.api_server: [avatar]` in Hermes config.yaml — exact key unconfirmed, check `hermes config --help`
- `API_SERVER_KEY` required, no default, even on loopback
- Verify: `GET /v1/toolsets` with auth header should list "avatar"

---

## Backend: hermes-avatar-companion/backend/

### File structure
```
backend/
  hermes_client.py      ← DONE, tested 14/14
  character.py          ← DONE, tested 17/17
  orchestrator.py       ← DONE, tested 5/5
  settings.py           ← DONE, tested 16/16
  tts.py                ← DONE, tested 7/7
  voice_input.py        ← DONE, tested 13/13
  real_voice_engines.py ← DONE, tested 6/6 (import guards only — no network)
  speech_output.py      ← DONE, tested 11/11
  server.py             ← syntax-only (websockets not installed in sandbox)
  main.py               ← NOT STARTED
  tests/
    test_hermes_client.py
    test_character.py
    test_orchestrator.py
    test_settings.py
    test_tts.py
    test_voice_input.py
    test_real_voice_engines.py
    test_speech_output.py
```

### hermes_client.py — key points
- `HermesClient(base_url, api_key, session_key, timeout=60.0, transport=None)`
- Raises ValueError immediately if api_key is empty
- `.send(text, instructions, conversation="companion")` → AsyncIterator[HermesEvent]
- Events: TextDelta(text), ToolCall(call_id, name, arguments), ResponseComplete(response_id), StreamError(detail)
- SSE parsed via `_parse_sse()` (async generator) → `_handle_event()` per event
- Two-phase tool call: `response.output_item.added` gives name, `response.function_call_arguments.done` gives full JSON arguments, correlated by call_id in pending_calls dict
- `transport` param: callable(method, url, json, headers) → Response — for testing without a real gateway
- CONFIRMED from docs: endpoint is `/v1/responses`, NOT `/v1/runs`
- UNCONFIRMED: exact byte-for-byte SSE event names from a real live Hermes instance (spec says "spec-native", assumed correct)

### character.py — key points
- `Character` dataclass: id, name, directory, model_path (required, no fallback), icon_path (optional), description, personality, characteristics, interaction_style, vocabulary, dialogue_examples, quirks, forbidden, system_prompt, voice, greeting, mood_baseline(0-1), mood_volatility(0-1)
- `load_character(directory: Path) → Character` — raises `CharacterLoadError` if model.vrm missing, name blank, mood out of range, etc.
- `character.to_instructions()` → full string for Hermes `instructions` field: system_prompt + personality + vocabulary + quirks + forbidden + dialogue_examples
- `CharacterLoader(dir).load_all()` — fails loud if any character is broken (not silently skipped)

### orchestrator.py — key points
- `event_to_wire_message(event) → dict` — exhaustive, raises TypeError on unknown type
- Wire messages: `{type:"text_delta", text}`, `{type:"tool_call", name, arguments}`, `{type:"turn_complete", response_id}`, `{type:"error", detail}`
- `CompanionOrchestrator(hermes_client, character, broadcast, conversation="companion")`
- `set_character(character)` — takes effect on next utterance
- `set_broadcast(fn)` — public method to rebind broadcast target (used by server.py on startup)
- `handle_utterance(text)` — never raises; StreamError becomes an error wire message

### settings.py — key points
- Sections: ConnectionSettings, STTSettings, TTSSettings, OverlaySettings, GeneralSettings
- All validate() methods raise SettingsValidationError with actionable messages
- STT modes: "wake_word" | "push_to_talk" | "both"
- VAD aggressiveness: 0-3 (webrtcvad's actual valid range)
- `Settings.load(path)` — returns defaults if file doesn't exist (first run), errors loudly if file exists but is malformed
- `Settings.save(path)` — creates parent dirs automatically

### tts.py — key points
- `TTSEngine` ABC: `async synthesize(text, voice) → TTSResult` — raises TTSError, never returns empty
- `TTSResult(audio: bytes, sample_rate: int, format: str)`
- `FakeTTSEngine(fail_on=None)` — deterministic, no network, audio=text.encode()
- `EdgeTTSEngine` — real implementation, NOT executed (edge-tts not installed in sandbox)
- `create_engine(name: str) → TTSEngine` — raises TTSError for unknown name

### voice_input.py — key points
- `VoiceInputPipeline(wake_word_detector, vad, stt_engine, mode, silence_timeout_frames=15)`
- `await process_audio_frame(frame) → Optional[str]` — returns transcript when wake-word utterance completes
- `push_to_talk_pressed()` / `await push_to_talk_released() → Optional[str]`
- `is_speaking(frame) → bool` — for barge-in detection, does NOT affect state
- KEY ISOLATION: PTT-started recording ignores silence timeout. Wake-word-started recording ignores PTT release. Tested explicitly.
- Interfaces: WakeWordDetector.process_frame(frame)→bool, VoiceActivityDetector.is_speech(frame)→bool, STTEngine.transcribe(audio)→str

### real_voice_engines.py — key points
- OpenWakeWordDetector(model_path, threshold=0.5) — wraps openwakeword.model.Model
- WebRTCVAD(aggressiveness=2, sample_rate=16000) — wraps webrtcvad.Vad
- FasterWhisperSTT(model_size="base", device="cpu", compute_type="int8") — wraps faster_whisper.WhisperModel
- ALL: argument validation happens BEFORE the import attempt (so bad args raise ValueError not VoiceEngineError)
- ALL: raise VoiceEngineError with "package not installed" message if library missing
- None actually executed — no network to install any of the three

### speech_output.py — key points
- `SpeechOutput(tts_engine, voice, on_audio, on_error=None)`
- `await feed_text(text)` — buffers text, fires TTS per complete sentence
- `await flush()` — synthesizes remaining buffer even without terminal punctuation
- Sentence boundary: `[.!?]["')]?(?=\s|$)` but periods after known abbreviations (Mr, Dr, etc.) are skipped
- `on_audio(TTSResult, sentence)` called per completed sentence — this is where audio bytes go to the shell
- TTS failure calls on_error (if set), never raises

### server.py — key points
- `CompanionServer(orchestrator, host="127.0.0.1", port=8765)`
- Constructor calls `orchestrator.set_broadcast(self.broadcast)` — this is how the broadcast chain gets wired
- Incoming: `{type:"utterance", text}` → orchestrator.handle_utterance(text)
- `switch_character` message received but NOT wired yet (needs CharacterLoader reference)
- Uses websockets library — NOT executed (not installed in sandbox)
- `websockets.broadcast()` used if available, falls back to manual gather loop for older versions

---

## main.py — NOT STARTED

Needs to:
1. Load Settings from `~/.config/hermes-companion/settings.json`
2. Load CharacterLoader from `~/.config/hermes-companion/characters/`
3. Construct: HermesClient, active Character, FakeTTSEngine (swap to EdgeTTSEngine when ready), VoiceInputPipeline with real engines
4. Construct SpeechOutput with on_audio → send audio wire message to shell
5. Construct CompanionOrchestrator
6. Construct CompanionServer — this wires the broadcast chain
7. Wire voice pipeline: on transcript → orchestrator.handle_utterance()
8. Wire barge-in: poll is_speaking() during TTS playback → cancel in-flight Hermes stream (cancel the asyncio task)
9. Run server + voice listener concurrently (asyncio.gather)

---

## Electron shell — NOT STARTED

Key constraints confirmed:
- BrowserWindow: frame:false, transparent:true, skipTaskbar:true, hasShadow:false, alwaysOnTop:true + 'screen-saver' level on macOS
- setVisibleOnAllWorkspaces(true, {visibleOnFullScreen:true}) for macOS Spaces
- Dynamic click-through: setIgnoreMouseEvents(true,{forward:true}) by default, toggle off when cursor enters avatar bounds (hit-test avatar on every mousemove even while "ignoring")
- Mouse behaviors: drag=move avatar, scroll=resize avatar, right-click=hide, cursor-on-nothing=click-through
- VRM rendering: three.js + @pixiv/three-vrm (vendored), fresh rewrite — do NOT copy from legacy.zip
- Lipsync: sentence audio → frequency analysis → viseme schedule → drive blendshapes (same concept as legacy, fresh code)
- Emotion: driven by tool_call wire messages from backend (set_emotion)
- Animations: VRMA clips from shared library, driven by tool_call wire messages (play_animation)
- Life-state machine: idle → bored (30s) → sleeping (2min) → auto-wake on next utterance
- IPC to backend: WebSocket client connecting to ws://127.0.0.1:8765

Wire message handling in shell:
- text_delta → show subtitle
- tool_call name="set_emotion" → drive face blendshapes
- tool_call name="play_animation" → play VRMA clip
- tool_call name="show_overlay" / "hide_overlay" → show/hide window
- tool_call name="move_avatar" → move avatar element within overlay
- tool_call name="resize_avatar" → scale avatar element
- turn_complete → stop subtitle display, flush any pending lipsync
- error → show disconnected state on avatar

---

## Confirmed facts (don't re-research)
- Hermes gateway endpoint: POST /v1/responses (NOT /v1/runs — confirmed from source)
- SSE event names: response.output_text.delta, response.output_item.added, response.function_call_arguments.done, response.completed (OpenAI Responses API spec — "spec-native" per Hermes docs)
- Session handling: X-Hermes-Session-Key (stable per-thread), conversation: "companion" in body
- API_SERVER_KEY: required, no default, even on loopback 127.0.0.1
- Hermes Desktop + Companion can run simultaneously on same gateway — separate session keys
- Plugin tools only available if enabled in platform_toolsets.api_server in config.yaml
- GET /v1/toolsets to verify tools are loaded before use
- Petdex: cosmetic 2D sprite, no voice/lipsync/3D — not a replacement for what we're building
- Obsidian integration: bundled Hermes skill, OBSIDIAN_VAULT_PATH env var — drop Amalgam's vault.py entirely

## What to tell a new session
"Continue building the Hermes Avatar Companion from HANDOFF.md. The sandbox lost all files. Rebuild backend from scratch using the exact specs in that doc — every module, its exact API, key design decisions, what's unexecuted and why. Start with hermes_avatar_tools/ plugin, then backend modules in this order: hermes_client.py, character.py, orchestrator.py, settings.py, tts.py, voice_input.py, real_voice_engines.py, speech_output.py, server.py, main.py. Then the Electron shell. Test every module with real tests as you go — no fake ones."
