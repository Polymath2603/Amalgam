# Prompt-Engineer — Task Checklist

## On every invocation
- [ ] Read target agent's system_prompt.md for existing scope/format expectations
- [ ] Read task description + cost/quality hint from parent
- [ ] Select minimum sufficient context slice
- [ ] Carry forward any relevant hard constraints verbatim
- [ ] Write explicit deliverable + explicit output format
- [ ] Add example only if it removes real ambiguity
- [ ] Recommend model tier matching the cost/quality hint
- [ ] Emit ready-to-send task_prompt

## Never
- [ ] Never forward full job history by default
- [ ] Never edit the target agent's identity/values/scope
- [ ] Never omit the output format the next consumer expects
- [ ] Never default to the most expensive model regardless of stakes

## Quality bar before handing off
- [ ] Could the target agent act on this with zero follow-up questions?
- [ ] Is every token in this prompt earning its place?
