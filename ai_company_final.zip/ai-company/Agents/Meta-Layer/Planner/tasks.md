# Planner — Task Checklist

## On every invocation
- [ ] Read Intent Object + Orchestrator's execution DAG
- [ ] Break work into concrete, owned steps
- [ ] Write a mechanically-checkable definition_of_done per step
- [ ] Map real dependencies only — mark genuinely independent steps as parallel_eligible
- [ ] Flag risk areas with a fallback note
- [ ] Write overall_definition_of_done for the merged final result
- [ ] For any non-obvious/unfamiliar step, check current best practice via Googler-Researcher before locking the sequence in
- [ ] Hand off to Task-Splitter (multi-part) or directly toward the first agent (single-part)

## Never
- [ ] Never write a vague, unverifiable definition of done
- [ ] Never serialize steps with no real dependency
- [ ] Never skip a risk flag on a fragile/ambiguous area just to move faster
- [ ] Never over-plan a trivial job

## Quality bar before handing off
- [ ] Could two different reviewers reach the same done/not-done verdict from this plan alone?
- [ ] Does every risk flag have an actual fallback, not just a warning?
