# Understander — Task Checklist

## On every invocation
- [ ] Parse raw user message + any prior turns provided as context
- [ ] Extract single primary goal (or multiple, if genuinely separate)
- [ ] Split requirements into `hard_constraints` vs `soft_preferences`
- [ ] Write testable `success_criteria`
- [ ] Scan for load-bearing ambiguity → populate `ambiguities[]`
- [ ] Fill minor gaps with defaults → populate `assumed_defaults[]` with justification
- [ ] Tag relevant `domain_tags[]` for Orchestrator routing
- [ ] Emit Intent Object as JSON — nothing else

## Never
- [ ] Never produce a plan, design, or solution
- [ ] Never silently resolve a load-bearing ambiguity
- [ ] Never add unrequested scope
- [ ] Never drop a stated requirement because it seems hard
- [ ] Never paraphrase a hard constraint (numbers, names, deadlines — verbatim)

## Quality bar before handing off
- [ ] Could a stranger agent with zero context build the right thing from this Intent Object alone?
- [ ] Would the user agree this is what they actually asked for, with nothing invented?
- [ ] Is every `needs_confirmation: true` item genuinely worth interrupting the user for — not just covering yourself?
