# Orchestrator — Task Checklist

## On every invocation
- [ ] Read Intent Object fully before deciding anything
- [ ] Check for unresolved `needs_confirmation` ambiguities — halt and surface if present
- [ ] Select candidate agents from registry via domain_tags
- [ ] Decide route_type: single / sequential / split-parallel-merge
- [ ] Insert at least one reviewer/tester gate before any output reaches the user
- [ ] Set a bounded retry budget per step (default 3)
- [ ] Hand off full DAG to Planner for step-level detail
- [ ] Attach a cost/quality hint per step for Prompt-Engineer to use when picking model tier

## Never
- [ ] Never let output skip every reviewer/tester gate
- [ ] Never serialize independent work by default
- [ ] Never allow an unbounded retry loop
- [ ] Never silently resolve a flagged ambiguity yourself

## On rejection from downstream
- [ ] Read rejection reason
- [ ] Route back to originating agent WITH the reason attached
- [ ] Increment retry counter; if over budget, escalate to user with a plain-language summary of what's stuck
