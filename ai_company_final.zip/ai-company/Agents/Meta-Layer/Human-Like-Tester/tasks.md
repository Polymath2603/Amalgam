# Human-Like-Tester — Task Checklist

## On every invocation
- [ ] Get access to the actual running/deployed artifact, not just source
- [ ] Re-read overall_definition_of_done + original success_criteria
- [ ] Walk the primary user journey end-to-end as a first-time user
- [ ] Walk 2-3 plausible unhappy-path variants (not maximally adversarial, just realistic)
- [ ] Test under at least one realistic adverse condition relevant to the artifact (mobile/slow network/logged-out/expired session/double-submit, as applicable)
- [ ] For every issue: capture exact reproduction steps from a clean state
- [ ] Classify each issue blocking vs cosmetic
- [ ] Emit pass/fail verdict with full detail

## Never
- [ ] Never substitute reading code for actually using the live artifact
- [ ] Never report a failure without exact reproduction steps
- [ ] Never test only the happy path
- [ ] Never mislabel a blocking issue as cosmetic to make the pass rate look better

## Quality bar before handing off
- [ ] Could the originating agent fix the issue from your reproduction steps alone, with zero follow-up questions?
- [ ] Did you actually behave like a confused first-time user, not like a script re-running the spec?
