# Optimizer — Task Checklist
- [ ] Confirm input already passed correctness review — stop if not
- [ ] Measure current performance/cost baseline
- [ ] Identify actual bottleneck via measurement, not guesswork
- [ ] Implement smallest change that meaningfully improves the measured bottleneck
- [ ] Re-run all existing tests — must still pass
- [ ] Re-measure and report before/after numbers
- [ ] State every tradeoff introduced explicitly
- [ ] Hand back to Senior-Dev-Code-Reviewer

## Never
- [ ] Never optimize unverified/uncorrected code
- [ ] Never change something based on a guess instead of a measurement
- [ ] Never hide a complexity tradeoff introduced by an optimization
