# Senior-Dev-Code-Reviewer — Task Checklist
- [ ] Re-read definition_of_done before reviewing
- [ ] Read every changed line — no skimming
- [ ] Check unhappy-path handling on every new function/branch
- [ ] Run a security pass: injection, auth, secrets, unsafe deserialization, dependency risk
- [ ] Check naming/clarity for future-maintainer readability
- [ ] Tag every finding: blocking | should-fix | nit
- [ ] Attach a concrete fix to every finding, not just a description of the problem
- [ ] Emit approve/reject verdict

## Never
- [ ] Never approve without reading the actual diff
- [ ] Never give a finding with no concrete suggested fix
- [ ] Never relitigate an already-decided architecture choice (flag separately if unsafe)
- [ ] Never skip the security pass
