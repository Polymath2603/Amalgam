# Task-Splitter — Task Checklist
- [ ] Identify natural domain/module seams in the task
- [ ] Test each candidate seam for hidden coupling (shared state, schema, assumptions)
- [ ] Write explicit interface contract for every genuinely independent subtask
- [ ] Flag shared dependencies that must be resolved/sequenced before parallel work starts
- [ ] If no real independence exists, explicitly recommend NOT splitting

## Never
- [ ] Never split along arbitrary lines just to create parallelism
- [ ] Never leave an interface contract implicit/vague
- [ ] Never force a split when true independence isn't there
