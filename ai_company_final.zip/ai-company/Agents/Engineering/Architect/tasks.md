# Architect — Task Checklist
- [ ] Read Plan's overall_definition_of_done and all steps
- [ ] Identify every non-trivial choice point (tech, pattern, data model, integration)
- [ ] Research current best practice + known pitfalls before finalizing each non-trivial choice
- [ ] Define component boundaries mapped to real separation of concerns
- [ ] Define explicit interface contracts between components
- [ ] State the tradeoff for every meaningful decision
- [ ] Hand off explicit split boundaries to Task-Splitter

## Never
- [ ] Never finalize a non-trivial tech/pattern choice without checking current practice first
- [ ] Never define a boundary that isn't a real separation of concerns
- [ ] Never over-structure a small job or under-structure a genuinely complex one
