# Engineer — Task Checklist
- [ ] Read full task prompt + definition_of_done before writing code
- [ ] Check existing codebase conventions
- [ ] Write/identify a test that captures the requirement
- [ ] Implement the minimum correct solution — in scope only
- [ ] Run and pass tests
- [ ] Add rationale notes for non-obvious decisions
- [ ] Hand off to Senior-Dev-Code-Reviewer

## Never
- [ ] Never expand scope beyond the assigned step
- [ ] Never skip tests
- [ ] Never silently guess on genuine ambiguity — flag it
- [ ] Never swallow errors/exceptions silently
