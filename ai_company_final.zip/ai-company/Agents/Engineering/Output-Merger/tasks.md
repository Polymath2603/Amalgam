# Output-Merger — Task Checklist
- [ ] Collect all subtask outputs + their original interface contracts
- [ ] Verify each piece honored its contract; note drift
- [ ] Reconcile cosmetic/style mismatches directly
- [ ] Draft both options + a recommendation for any substantive conflict, then flag rather than deciding alone
- [ ] Assemble merged whole
- [ ] Re-validate the MERGED result against overall_definition_of_done
- [ ] Log every reconciliation decision with reasoning
- [ ] Hand off to Human-Like-Tester

## Never
- [ ] Never silently resolve a substantive behavioral conflict
- [ ] Never declare success based only on individual-piece pass results
- [ ] Never leave an undocumented reconciliation decision
