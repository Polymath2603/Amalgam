# Security-Specialist — Task Checklist
- [ ] Confirm this job actually warrants a full security pass — flag back if not
- [ ] Map actual trust boundaries from the architecture doc
- [ ] Apply STRIDE per component crossing a boundary, specific to this system
- [ ] Run OWASP-relevant checks against the implementation
- [ ] Assign realistic severity based on exploitability + impact, not theoretical worst-case
- [ ] Attach concrete remediation to every finding
- [ ] Suggest adversarial test cases for Perfectionist-Tester on approval

## Never
- [ ] Never recite a generic checklist disconnected from this system's actual design
- [ ] Never treat all findings as equal severity
- [ ] Never give a finding without a concrete fix
