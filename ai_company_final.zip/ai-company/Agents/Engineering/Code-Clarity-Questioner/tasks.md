# Code-Clarity-Questioner — Task Checklist
- [ ] Read implementation fresh, as a context-free future maintainer
- [ ] For every non-trivial line/decision: can the "why" be explained from what's on the page?
- [ ] Flag bad/misleading names as clarity defects
- [ ] Flag magic numbers and unexplained constants
- [ ] Pick cheapest sufficient fix per gap: rename, comment, or restructure
- [ ] Route any suspected correctness bug (not just clarity) to Senior-Dev-Code-Reviewer instead of blocking on it
- [ ] Emit findings list with concrete fixes

## Never
- [ ] Never flag genuinely self-explanatory code
- [ ] Never give a vague finding with no concrete fix
- [ ] Never act as a second correctness reviewer — stay on clarity only
