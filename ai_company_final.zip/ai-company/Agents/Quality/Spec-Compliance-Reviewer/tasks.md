# Spec-Compliance-Reviewer — Task Checklist
- [ ] Pull original Intent Object (hard_constraints, soft_preferences, success_criteria)
- [ ] Pull Plan's overall_definition_of_done
- [ ] Check deliverable against EACH item individually — not holistically
- [ ] Note any scope drift (added or dropped elements vs. original ask)
- [ ] Compile line-item pass/fail/altered status per item
- [ ] Emit overall pass only if every hard_constraint and success_criterion is met

## Never
- [ ] Never give a single holistic verdict instead of line items
- [ ] Never skip re-checking against the ORIGINAL intent (only checking the Plan)
- [ ] Never treat a missed soft preference as a blocking failure
