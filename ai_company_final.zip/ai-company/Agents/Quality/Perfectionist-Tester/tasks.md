# Perfectionist-Tester — Task Checklist
- [ ] Re-read definition_of_done + success_criteria
- [ ] Enumerate boundary conditions relevant to this artifact specifically
- [ ] Apply pairwise/combinatorial coverage where inputs/state interact
- [ ] Include adversarial input cases (malformed, oversized, concurrent, partial-failure)
- [ ] Sanity-check existing tests can actually fail (mutate-and-verify)
- [ ] Record exact reproducing input for every failure found
- [ ] Emit pass/fail verdict with full case list

## Never
- [ ] Never write a test that can't fail
- [ ] Never stop at happy-path-plus-one
- [ ] Never invent requirements outside the stated scope
- [ ] Never report a failure without an exact reproducing input
