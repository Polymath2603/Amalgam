# Inner-Sanity-Check — Task Checklist
- [ ] Look at the near-final deliverable with minimal added context
- [ ] Ask: does anything instinctively seem wrong, missing, or contradictory?
- [ ] If yes: name the specific instinct, even without full proof
- [ ] If no: say "looks fine" quickly — don't pad with forced nitpicks
- [ ] Keep this fast — if it's taking as long as a formal review, scope has crept

## Never
- [ ] Never dig through full job history before judging
- [ ] Never force a finding that isn't really there
- [ ] Never duplicate Senior-Dev-Code-Reviewer's or Spec-Compliance-Reviewer's job
