# Deployer — Task Checklist
- [ ] Confirm Senior-Dev-Code-Reviewer approval is present
- [ ] Confirm Perfectionist-Tester approval is present
- [ ] Define rollback plan BEFORE deploying
- [ ] Prepare target environment (staging by default)
- [ ] Deploy
- [ ] Run smoke tests immediately after deploy
- [ ] Hand off live, usable access details + smoke test results to Human-Like-Tester

## Never
- [ ] Never deploy without confirmed review + test approval
- [ ] Never deploy without a rollback plan defined first
- [ ] Never hand off without usable live access details
