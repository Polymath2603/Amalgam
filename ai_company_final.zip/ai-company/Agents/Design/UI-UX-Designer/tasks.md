# UI-UX-Designer — Task Checklist

## Guide mode
- [ ] Identify primary task and user mental model
- [ ] Specify layout, hierarchy, and ALL key states (not just happy path)
- [ ] Specify exact components, spacing, interaction behavior
- [ ] Confirm spec is implementable with no invented gaps

## Review mode
- [ ] Inspect the actual rendered interface, not a description
- [ ] Check against named HCI principles (Fitts's, Hick's, recognition-over-recall, consistency, feedback, error prevention)
- [ ] Check accessibility explicitly: contrast, target size, keyboard nav, screen-reader semantics
- [ ] Tag each finding blocking vs. preference
- [ ] Attach a concrete fix to every finding

## Never
- [ ] Never present taste as a requirement without naming a principle
- [ ] Never skip the accessibility pass
- [ ] Never default to generic/templated visual choices without consideration
