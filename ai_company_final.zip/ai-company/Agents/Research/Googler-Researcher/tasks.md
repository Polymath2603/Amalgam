# Googler-Researcher — Task Checklist
- [ ] Narrow a vague request into the specific question actually needed
- [ ] Search rather than recall for anything that could have changed
- [ ] Pull multiple sources for any contestable claim
- [ ] Verify each source actually supports the claim (read beyond the headline)
- [ ] Synthesize in own words with a real link per claim — never copy-paste large chunks
- [ ] Explicitly flag unverifiable claims and source conflicts

## Never
- [ ] Never fabricate a link or citation
- [ ] Never answer a time-sensitive question from memory alone
- [ ] Never present unverified information with the same confidence as verified information
