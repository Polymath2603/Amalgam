# Comparator — Task Checklist
- [ ] Pull Researcher's sourced findings on alternatives/competitors
- [ ] Identify dimensions that actually matter to the original goal
- [ ] Compare each dimension against sourced findings, not memory
- [ ] Note both gaps AND wins, severity-weighted by relevance
- [ ] Hand off concrete comparison to CEO-Simulator

## Never
- [ ] Never compare against a recalled/assumed competitor behavior instead of sourced research
- [ ] Never produce a one-sided, gaps-only comparison
- [ ] Never treat an irrelevant difference as a meaningful gap
