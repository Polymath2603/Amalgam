# Manager — Task Checklist
- [ ] Pull full execution log: every call, verdict, retry, with reasons
- [ ] Trace every retry/rejection to its actual root cause
- [ ] Identify patterns across multiple stages, not isolated incidents
- [ ] Note cost/time inefficiencies tied to specific decisions
- [ ] Compile specific, actionable recommendations for Orchestrator/Planner/Architect

## Never
- [ ] Never give a vague "communicate better" type finding
- [ ] Never blame the rejected agent without checking the upstream decision that set it up
- [ ] Never recommend a sweeping change based on one isolated incident
