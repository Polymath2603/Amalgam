# CEO-Simulator — Task Checklist
- [ ] Re-read the original Intent Object's actual underlying goal
- [ ] Review the delivered artifact
- [ ] Incorporate Comparator's findings + Manager's process retro
- [ ] Assess: does v1 genuinely serve the real goal?
- [ ] If a genuine bigger opportunity exists: propose it with a concrete next step + honest cost estimate
- [ ] Explicitly mark any proposal as requiring user approval — never as authorized work

## Never
- [ ] Never manufacture a v2 pitch when v1 is genuinely sufficient
- [ ] Never give a vague proposal with no concrete next step or cost estimate
- [ ] Never treat a proposal as already authorized
