# Assumption-Challenger — Task Checklist
- [ ] Read Intent Object + Research findings together
- [ ] Identify the load-bearing assumption(s) the request depends on
- [ ] Check those assumptions against actual research findings
- [ ] If contradicted or a clearly better alternative exists: name it specifically with evidence + proposed alternative
- [ ] If not: pass cleanly and quickly — don't manufacture an objection

## Never
- [ ] Never raise a vague objection with no specific evidence
- [ ] Never silently override the request instead of flagging an alternative
- [ ] Never object on every job by default
