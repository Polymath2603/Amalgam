# AI Company — Multi-Agent Harness

A simulated company org structure as an AI agent pipeline: research → question → plan → architect → split → build → merge → review → fix → test (code) → deploy → test (human) → fix → deliver → improve.

## What's actually in this build (honest scope)

The original ask was for **all 100+ roles**. That's still not in here, and won't be faked with fabricated links. What changed in this revision: the roster grew from 16 to **23 real agents**, fixing one genuine gap (nothing was deploying anything) and adding the explicit research/question/architecture/improvement stages.

- **5 Meta-Layer agents** — the harness (Understander, Orchestrator, Prompt-Engineer, Planner, Human-Like-Tester)
- **8 Engineering agents** — Engineer, Senior-Dev-Code-Reviewer, Architect, Security-Specialist, Task-Splitter, Output-Merger, Optimizer, Code-Clarity-Questioner
- **3 Quality agents** — Perfectionist-Tester, Spec-Compliance-Reviewer, Inner-Sanity-Check
- **1 Operations agent** — Deployer (fills the gap: stands up a live environment so Human-Like-Tester has something real to test)
- **4 Strategy agents** — Assumption-Challenger (the "question" stage), CEO-Simulator, Manager, Comparator (the post-build improvement loop)
- **1 Design agent** — UI-UX-Designer
- **1 Research agent** — Googler-Researcher (now also a *mandatory* early pipeline stage, not just an on-demand utility)
- **Skills.json** — 33 entries, every link verified by live search. Newest batch sourced from `garrytan/gstack` (MIT, a real production multi-agent dev-team harness — direct, validating prior art for almost this entire design) and `alirezarezvani/claude-cto-team`.
- **Two n8n workflows**: the main build spine (`ai-company-harness.json`, 42 nodes) and a separate, genuinely recursive **Continuous-Improvement-Loop** (`continuous-improvement-loop.json`, 17 nodes) that can call back into the main spine — gated behind two independent safeguards: an iteration cap, and a hard requirement that a human approves before any v2 build starts.

## Roster size vs. pipeline depth — the distinction that matters

Two different knobs, often confused:
- **Roster size** (how many specialists *exist*): keep growing this. More precise domain matching, no real downside.
- **Agents activated per job** (how many *run* on one request): should stay tight. The Orchestrator picks ~4-10 relevant agents out of the roster per job — running all 23 (or all 100+) on every request would be slow and absurdly expensive for zero benefit on simple jobs.

`Security-Specialist`, for example, is in the roster but deliberately NOT in the default linear pipeline — Orchestrator invokes it only when domain_tags indicate auth/payments/PII.

## Directory structure

```
ai-company/
├── Skills.json
├── Agents/
│   ├── Meta-Layer/        Understander · Orchestrator · Prompt-Engineer · Planner · Human-Like-Tester
│   ├── Engineering/       Engineer · Senior-Dev-Code-Reviewer · Architect · Security-Specialist ·
│   │                      Task-Splitter · Output-Merger · Optimizer · Code-Clarity-Questioner
│   ├── Quality/           Perfectionist-Tester · Spec-Compliance-Reviewer · Inner-Sanity-Check
│   ├── Operations/        Deployer
│   ├── Strategy/          Assumption-Challenger · CEO-Simulator · Manager · Comparator
│   ├── Design/UI-UX-Designer/
│   └── Research/Googler-Researcher/
└── n8n/
    ├── ai-company-harness.json          (main build spine, 42 nodes)
    └── continuous-improvement-loop.json  (separate recursive improvement loop, 17 nodes)
```

Each agent folder: `about.json` · `system_prompt.md` · `tasks.md` · `skills.json` — same as before.

## The pipeline, in order

1. **Understander** — raw message → structured Intent Object.
2. *(clarification gate — pauses here if real ambiguity exists)*
3. **Googler-Researcher** — mandatory, every job: how is this conventionally solved, current best practice, known pitfalls.
4. **Assumption-Challenger** — the explicit "question" stage. Pressure-tests the idea + research, before any plan exists. *(objection gate — pauses if a fundamental problem with the premise is found)*
5. **Orchestrator** — decides which agents/route this specific job needs.
6. **Planner** — detailed plan, concrete steps, checkable definition_of_done each. Now has an explicit hard rule: research before locking in any non-obvious step.
7. **Architect** — turns the plan's WHAT into a concrete HOW: component boundaries, interfaces, tech/pattern choices with research-backed tradeoffs.
8. **Task-Splitter** — splits along Architect's real boundaries, not arbitrary ones.
9. **Prompt-Engineer → specialist agent → domain quality gate**, repeated per step, bounded retries (cap: 3).
10. **Output-Merger** — combines everything; resolves conflicts.
11. **Spec-Compliance-Reviewer** — checks the merged result against the ORIGINAL Intent Object.
12. **Deployer** — *(the previously-missing stage)* stands up a real/staging environment.
13. **Human-Like-Tester** — uses the live thing like a real person, not the source.
14. **Inner-Sanity-Check** — cheap, fast, fresh-eyes gut check (Haiku-tier).
15. **Delivered to user.**
16. *(separate workflow, triggered post-delivery)* **Continuous-Improvement-Loop**: Comparator + Manager + CEO-Simulator propose a v2 — never auto-built, always awaiting explicit user approval, capped at 2 improvement cycles.

## Workflow architecture: both, not either/or

One "spine" workflow owns sequencing, retries, and state — that's `ai-company-harness.json`. Every specialist call inside it routes through the same lookup-driven generic caller (`Agent Registry`), so adding agent #24 means adding a registry row, not redrawing the canvas. The improvement loop is a genuinely **separate** workflow with its own lifecycle (runs once per delivered job, not per step) and its own agents — and it recurses back into the spine for real via n8n's Execute-Workflow node, gated behind an iteration cap AND explicit human approval, so the recursion can never run away on its own.


## Model tiering (the actual cost lever)

Not every agent should run on the same model:
- **Frontier tier (Opus-class):** Orchestrator, Planner, Senior-Dev-Code-Reviewer, Perfectionist-Tester — places where a mistake cascades or subtlety genuinely matters.
- **Mid tier (Sonnet-class):** Understander, Prompt-Engineer, Engineer, most reviewers — solid reasoning, runs on every job, cost matters.
- **Cheap/fast tier (Haiku-class):** Inner-Sanity-Check — deliberately. A gut-check doesn't need a frontier model; using one there is pure waste.

This mapping is encoded in every agent's `about.json` under `default_models`, and centralized in the n8n workflow's `Agent Registry` node.

## What's a placeholder, not finished

Said plainly, so you don't get burned in production:
- ~~The n8n HTTP nodes have `system: 'See Agents/.../system_prompt.md'` as a placeholder string.~~ **Fixed**: `Load System Prompts` now actually reads every agent's real `system_prompt.md` from disk at the start of each run (reusing `Agent Registry (lookup)`'s per-agent paths, so the roster stays defined in one place), and every `Call: <Agent>` node references the loaded content instead of a literal string. Two things this needs from your n8n instance:
  - `NODE_FUNCTION_ALLOW_BUILTIN=fs,path` set on the n8n process (self-hosted n8n only — Code nodes can't read the filesystem otherwise).
  - An `AI_COMPANY_REPO_PATH` environment variable pointing at your checkout of this `ai-company/` folder (defaults to the n8n process's working directory if unset).
  - If a `system_prompt.md` can't be read (wrong path, permissions, etc.), that agent's call gets a visible `[ERROR: could not read ...]` system prompt instead of failing silently — check the run log if a response looks confused.
- The Task-Splitter → N-way parallel fan-out is represented structurally but simplified to the common case (sequential plan with retries). True dynamic N-way parallelism needs n8n's Execute-Workflow-per-branch pattern layered on top.
- You need to create the `anthropicApi` credential in n8n (or swap in whatever provider you're using) before this runs at all.

## Extending to the remaining ~85 roles

Same 4-file pattern, same model-tiering logic, same Skills.json registry. Happy to keep building these out in batches — just say which department to do next (Leadership/C-suite, Sales & Marketing, Finance & Legal, HR, etc.) rather than asking for all of them in one pass; that's what kept this batch honest instead of padded with fabricated links.

## Security note (don't skip this)

`Skills.json` includes a `security_warning` field for a reason: third-party Claude Code / OpenClaw / Hermes skills can bundle executable code. An independent audit found roughly 1 in 4 community agent skills had real security issues, and at least one OpenClaw skill was caught actively exfiltrating data via prompt injection. Read every `SKILL.md` before installing anything from `Skills.json` into a system with real credentials.
